/** @type {import('next').NextConfig} */
const nextConfig = {
  // SSR 방식 (기본값)
  // output: 'export' 를 제거하면 SSR 활성화
}

export default nextConfig
